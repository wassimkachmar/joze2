/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define ENABLED                         (1u)
#define DISABLED                        (0u)

#define LED_ON                          (0u)
#define LED_OFF                         (1u)

#define CONNECTION_PARAMETER_ACCEPTED                               0x0000
#define CONNECTION_PARAMETER_REJECTED                               0x0001


/* [] END OF FILE */

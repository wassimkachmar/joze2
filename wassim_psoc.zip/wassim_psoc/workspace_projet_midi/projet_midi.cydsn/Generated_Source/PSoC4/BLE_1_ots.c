/***************************************************************************//**
* \file BLE_ots.c
* \version 3.61
* 
* \brief
*  Contains the source code for Object Transfer Service.
* 
********************************************************************************
* \copyright
* Copyright 2019, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "BLE_1_eventHandler.h"
#include "BLE_1_ots.h"


#ifdef CYBLE_OTS_SERVER
/* Generated code */
const CYBLE_OTSS_T cyBle_otss =
{
    0x0033u,    /* Handle of the OTS service */
    {
        
        /* OTS Feature characteristic */
        {
            0x0037u, /* Handle of the OTS Feature characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object Name characteristic */
        {
            0x0039u, /* Handle of the Object Name characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object Type characteristic */
        {
            0x003Cu, /* Handle of the Object Type characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object Size characteristic */
        {
            0x003Fu, /* Handle of the Object Size characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object First-Created characteristic */
        {
            0x0042u, /* Handle of the Object First-Created characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object Last-Modified characteristic */
        {
            0x0044u, /* Handle of the Object Last-Modified characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object ID characteristic */
        {
            0x0046u, /* Handle of the Object ID characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object Properties characteristic */
        {
            0x0048u, /* Handle of the Object Properties characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object Action Control Point characteristic */
        {
            0x004Au, /* Handle of the Object Action Control Point characteristic */ 
            
            /* Array of Descriptors handles */
            {
                0x004Bu, /* Handle of the Client Characteristic Configuration descriptor */ 
            }, 
        }, 
        
        /* Object List Control Point characteristic */
        {
            0x004Du, /* Handle of the Object List Control Point characteristic */ 
            
            /* Array of Descriptors handles */
            {
                0x004Eu, /* Handle of the Client Characteristic Configuration descriptor */ 
            }, 
        }, 
        
        /* Object List Filter characteristic */
        {
            0x0050u, /* Handle of the Object List Filter characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object List Filter 2 characteristic */
        {
            0x0052u, /* Handle of the Object List Filter 2 characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object List Filter 3 characteristic */
        {
            0x0054u, /* Handle of the Object List Filter 3 characteristic */ 
            
            /* Array of Descriptors handles */
            {
                CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE, 
            }, 
        }, 
        
        /* Object Changed characteristic */
        {
            0x0056u, /* Handle of the Object Changed characteristic */ 
            
            /* Array of Descriptors handles */
            {
                0x0057u, /* Handle of the Client Characteristic Configuration descriptor */ 
            }, 
        }, 
    },
};
/* End of generated code */

static CYBLE_GATT_DB_ATTR_HANDLE_T cyBle_otssReqHandle;
    
#endif /* CYBLE_OTS_SERVER */

#ifdef CYBLE_OTS_CLIENT
    
/* Server's Object Transfer Profile characteristics GATT DB handles structure */
CYBLE_OTSC_T cyBle_otsc;

CYBLE_GATT_DB_ATTR_HANDLE_T cyBle_otscReqHandle;

/* Read Long Descriptors variables */
static uint8 * cyBle_otscRdLongBuffPtr = NULL;
static uint8 cyBle_otscRdLongBuffLen = 0u;
static uint8 cyBle_otscCurrLen = 0u;

#endif /* (CYBLE_OTS_CLIENT) */

static CYBLE_CALLBACK_T CyBle_OtsApplCallback = NULL;


/******************************************************************************
* Function Name: CyBle_OtsInit
***************************************************************************//**
* 
*  This function initializes the Object Transfer Service.
* 
******************************************************************************/
void CyBle_OtsInit(void)
{

#ifdef CYBLE_OTS_CLIENT

    cyBle_otscRdLongBuffPtr = NULL;
    cyBle_otscRdLongBuffLen = 0u;
    cyBle_otscCurrLen = 0u;

    
    if(cyBle_serverInfo[CYBLE_SRVI_OTS].range.startHandle == CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
    {
        (void)memset(&cyBle_otsc, 0, sizeof(cyBle_otsc));
    }
    cyBle_otscReqHandle = CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE;    
    

#endif /* CYBLE_OTS_CLIENT */

}

/******************************************************************************
* Function Name: CyBle_OtsRegisterAttrCallback
***************************************************************************//**
* 
*  Registers a callback function for service specific attribute operations.
*  Service specific write requests from peer device will not be handled with
*  unregistered callback function.
* 
*  \param callbackFunc:  An application layer event callback function to receive
*                 events from the BLE Component. The definition of
*                 CYBLE_CALLBACK_T for OTS Service is:\n
*                 typedef void (* CYBLE_CALLBACK_T) (uint32 eventCode,
*                                                    void *eventParam)
*                 * eventCode:  Indicates the event that triggered this callback
*                   (e.g. CYBLE_EVT_OTS_NOTIFICATION_ENABLED).
*                 * eventParam: Contains the parameters corresponding to the
*                   current event. (e.g. Pointer to CYBLE_OTS_CHAR_VALUE_T
*                   structure that contains details of the characteristic
*                   for which the notification enabled event was triggered).
* 
******************************************************************************/
void CyBle_OtsRegisterAttrCallback(CYBLE_CALLBACK_T callbackFunc)
{
    CyBle_OtsApplCallback = callbackFunc;
}


#ifdef CYBLE_OTS_SERVER

/******************************************************************************
* Function Name: CyBle_OtssWriteEventHandler
***************************************************************************//**
* 
*  Handles the Write Request Event.
* 
*  \param eventParam: The pointer to the data structure specified by the event.
* 
* \return
*  Return value is of type CYBLE_GATT_ERR_CODE_T.
*   * CYBLE_GATT_ERR_NONE - Write is successful.
*   * CYBLE_GATT_ERR_REQUEST_NOT_SUPPORTED - The request is not supported.
*   * CYBLE_GATT_ERR_INVALID_HANDLE - 'handleValuePair.attrHandle' is not valid.
*   * CYBLE_GATT_ERR_WRITE_NOT_PERMITTED - The write operation is not permitted on
*                                          this attribute.
*   * CYBLE_GATT_ERR_INVALID_OFFSET - The offset value is invalid.
*   * CYBLE_GATT_ERR_UNLIKELY_ERROR - Some other error occurred.
* 
******************************************************************************/
CYBLE_GATT_ERR_CODE_T CyBle_OtssWriteEventHandler(CYBLE_GATTS_WRITE_REQ_PARAM_T *eventParam)
{
    CYBLE_OTS_CHAR_VALUE_T locCharValue;
    locCharValue.gattErrorCode = CYBLE_GATT_ERR_NONE;
    
    if(CyBle_OtsApplCallback != NULL)
    {
        locCharValue.connHandle = eventParam->connHandle;
	 
        /* Error conditions for OTS Characteristic value write request */
        
        if((eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[CYBLE_OTS_OBJECT_ACTION_CONTROL_POINT].charHandle) && 
           (!CYBLE_IS_INDICATION_ENABLED(cyBle_otss.charInfo[CYBLE_OTS_OBJECT_ACTION_CONTROL_POINT].descrHandle[CYBLE_OTS_CCCD])))
        {
            locCharValue.gattErrorCode = CYBLE_GATT_ERR_CCCD_IMPROPERLY_CONFIGURED;
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
        else if((eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_CONTROL_POINT].charHandle) && 
           (!CYBLE_IS_INDICATION_ENABLED(cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_CONTROL_POINT].descrHandle[CYBLE_OTS_CCCD])))
        {
            locCharValue.gattErrorCode = CYBLE_GATT_ERR_CCCD_IMPROPERLY_CONFIGURED;
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
        else if((eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[CYBLE_OTS_OBJECT_CHANGED].charHandle) && 
           (!CYBLE_IS_INDICATION_ENABLED(cyBle_otss.charInfo[CYBLE_OTS_OBJECT_CHANGED].descrHandle[CYBLE_OTS_CCCD])))
        {
            locCharValue.gattErrorCode = CYBLE_GATT_ERR_CCCD_IMPROPERLY_CONFIGURED;
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
        else if(((eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_FILTER_1].charHandle) || 
                 (eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_FILTER_2].charHandle) || 
                 (eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_FILTER_3].charHandle)) &&
                ((eventParam->handleValPair.value.val[0] == CYBLE_OTS_OLF_CURRENT_SIZE_BETWEEN) && 
                 (CyBle_OtsGet32ByPtr(&eventParam->handleValPair.value.val[CYBLE_OTS_MIN_SIZE_PTR]) >
                  CyBle_OtsGet32ByPtr(&eventParam->handleValPair.value.val[CYBLE_OTS_MAX_SIZE_PTR]))))
        {
            locCharValue.gattErrorCode = (CYBLE_GATT_ERR_CODE_T)CYBLE_GATT_ERR_WRITE_REQ_REJECTED;
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
        else if(((eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_FILTER_1].charHandle) || 
                 (eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_FILTER_2].charHandle) || 
                 (eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_FILTER_3].charHandle)) &&
                 (eventParam->handleValPair.value.val[0] > CYBLE_OTS_OLF_MARKED_OBJECTS))
        {
            locCharValue.gattErrorCode = (CYBLE_GATT_ERR_CODE_T)CYBLE_GATT_ERR_WRITE_REQ_REJECTED;
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
        else if((eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[CYBLE_OTS_OBJECT_PROPERTIES].charHandle) &&
                 (CyBle_OtsGet32ByPtr(eventParam->handleValPair.value.val) >= (CYBLE_OTS_PROPERTY_MARK << 1u)))
        {
            locCharValue.gattErrorCode = (CYBLE_GATT_ERR_CODE_T)CYBLE_GATT_ERR_WRITE_REQ_REJECTED;
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
        else
    	{   for(locCharValue.charIndex = CYBLE_OTS_FEATURE;
                        locCharValue.charIndex < CYBLE_OTS_CHAR_COUNT; locCharValue.charIndex++)
    	    {
                if(eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[locCharValue.charIndex].charHandle)
    	        {   
                    locCharValue.value = &eventParam->handleValPair.value;
                    
                    if(locCharValue.gattErrorCode == CYBLE_GATT_ERR_NONE)
        	        {
                        CyBle_OtsApplCallback((uint32)CYBLE_EVT_OTSS_WRITE_CHAR, &locCharValue);
                    }
                    
                    if(locCharValue.gattErrorCode == CYBLE_GATT_ERR_NONE)
        	        {
                        locCharValue.gattErrorCode = CyBle_GattsWriteAttributeValue(&eventParam->handleValPair,
                                 0u, &eventParam->connHandle, CYBLE_GATT_DB_PEER_INITIATED);
                    }
                    
                    if(locCharValue.gattErrorCode == CYBLE_GATT_ERR_NONE)
                    {
                        CYBLE_GATT_DB_ATTR_SET_ATTR_GEN_LEN(cyBle_otss.charInfo[locCharValue.charIndex].charHandle,
                                                                                                locCharValue.value->len);
         	        }     
                    
                    /* Clear callback flag indicating that request was handled */
        			cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
                    locCharValue.charIndex = CYBLE_OTS_CHAR_COUNT; /* instead of break */
        	    }
        	    else if(eventParam->handleValPair.attrHandle == cyBle_otss.charInfo[locCharValue.charIndex].descrHandle[CYBLE_OTS_CCCD])
                {
                    locCharValue.value = NULL;
                    locCharValue.gattErrorCode = CyBle_GattsWriteAttributeValue(&eventParam->handleValPair,
                                 0u, &eventParam->connHandle, CYBLE_GATT_DB_PEER_INITIATED);
                    if(locCharValue.gattErrorCode == CYBLE_GATT_ERR_NONE)
                    {
                        uint32 eventCode;
      
                        if(CYBLE_IS_INDICATION_ENABLED_IN_PTR(eventParam->handleValPair.value.val))
                        {
                            eventCode = (uint32)CYBLE_EVT_OTSS_INDICATION_ENABLED;
                        }
                        else
                        {
                            eventCode = (uint32)CYBLE_EVT_OTSS_INDICATION_DISABLED;
                        }
                          
                        CyBle_OtsApplCallback(eventCode, &locCharValue);
                    
                    #if((CYBLE_GAP_ROLE_PERIPHERAL || CYBLE_GAP_ROLE_CENTRAL) && \
                        (CYBLE_BONDING_REQUIREMENT == CYBLE_BONDING_YES))
                        /* Set flag to store bonding data to flash */
                        if(cyBle_peerBonding == CYBLE_GAP_BONDING)
                        {
                            cyBle_pendingFlashWrite |= CYBLE_PENDING_CCCD_FLASH_WRITE_BIT;
                        }
                    #endif /* (CYBLE_BONDING_REQUIREMENT == CYBLE_BONDING_YES) */
    				}
                    
                    /* Clear callback flag indicating that request was handled */
                    cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
                    locCharValue.charIndex = CYBLE_OTS_CHAR_COUNT; /* instead of break */
    			}
                else
                {
                    /* Nothing else */    
                }
            }
        }
    }

    return (locCharValue.gattErrorCode);
}
/****************************************************************************** 
* Function Name: CyBle_OtssPrepareWriteRequestEventHandler
***************************************************************************//**
* 
*  Handles the Prepare Write Request Event.
* 
*  \param eventParam: The pointer to the data that comes with a prepare 
*                     write request.
*                                                  
******************************************************************************/
void CyBle_OtssPrepareWriteRequestEventHandler(CYBLE_GATTS_PREP_WRITE_REQ_PARAM_T *eventParam)
{

    if(CyBle_OtsApplCallback != NULL)
    {
        if((eventParam->baseAddr[eventParam->currentPrepWriteReqCount - 1u].handleValuePair.attrHandle ==
            cyBle_otss.charInfo[CYBLE_OTS_OBJECT_NAME].charHandle) || 
            (eventParam->baseAddr[eventParam->currentPrepWriteReqCount - 1u].handleValuePair.attrHandle ==
            cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_FILTER_1].charHandle) || 
            (eventParam->baseAddr[eventParam->currentPrepWriteReqCount - 1u].handleValuePair.attrHandle ==
            cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_FILTER_2].charHandle) || 
            (eventParam->baseAddr[eventParam->currentPrepWriteReqCount - 1u].handleValuePair.attrHandle ==
            cyBle_otss.charInfo[CYBLE_OTS_OBJECT_LIST_FILTER_3].charHandle))
        {
            if(cyBle_otssReqHandle == CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
            {
                /* Send Prepare Write Response which identifies acknowledgment for
                * long characteristic value write.
                */
                CyBle_GattsPrepWriteReqSupport(CYBLE_GATTS_PREP_WRITE_SUPPORT);

                cyBle_otssReqHandle =
                    eventParam->baseAddr[eventParam->currentPrepWriteReqCount - 1u].handleValuePair.attrHandle;
            }
            /* Indicate that request was handled */
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
    }
}

/****************************************************************************** 
* Function Name: CyBle_OtssExecuteWriteRequestEventHandler
***************************************************************************//**
* 
*  Handles the Execute Write Request Event.
* 
*  \param eventParam: The pointer to the data that came with a write request.
* 
******************************************************************************/
void CyBle_OtssExecuteWriteRequestEventHandler(CYBLE_GATTS_EXEC_WRITE_REQ_T *eventParam)
{
    uint8 locCount;
    CYBLE_OTS_CHAR_VALUE_T locCharValue[CYBLE_OTS_CHAR_COUNT];
    CYBLE_GATT_VALUE_T locGattValue[CYBLE_OTS_CHAR_COUNT];
    CYBLE_OTS_CHAR_INDEX_T locCharIndex;
    
    for(locCharIndex = CYBLE_OTS_FEATURE; locCharIndex < CYBLE_OTS_CHAR_COUNT; locCharIndex++)
    {
        locGattValue[locCharIndex].len = 0u;
        locGattValue[locCharIndex].val = NULL;
    }
    
    for(locCount = 0u; locCount < eventParam->prepWriteReqCount; locCount++)
    {
        for(locCharIndex = CYBLE_OTS_FEATURE; locCharIndex < CYBLE_OTS_CHAR_COUNT; locCharIndex++)
        {
            if(eventParam->baseAddr[locCount].handleValuePair.attrHandle ==
                cyBle_otss.charInfo[locCharIndex].charHandle)
            {
                locGattValue[locCharIndex].len = eventParam->baseAddr[locCount].offset + 
                                   eventParam->baseAddr[locCount].handleValuePair.value.len;

                if(locGattValue[locCharIndex].val == NULL)
                {
                    locGattValue[locCharIndex].val = eventParam->baseAddr[locCount].handleValuePair.value.val;
                }
                else if(eventParam->baseAddr[locCount].offset == 0u)
                {
                    /* Case when client wants to rewrite value from beginning */
                    locGattValue[locCharIndex].val = eventParam->baseAddr[locCount].handleValuePair.value.val;
                }
                else
                {
                    /* Do nothing */
                }
            }
        }
    }
    
    for(locCharIndex = CYBLE_OTS_FEATURE; locCharIndex < CYBLE_OTS_CHAR_COUNT; locCharIndex++)
    {
        if((locGattValue[locCharIndex].len != 0u) &&
           (locGattValue[locCharIndex].len <= 
            CYBLE_GATT_DB_ATTR_GET_ATTR_GEN_MAX_LEN(cyBle_otss.charInfo[locCharIndex].charHandle)))
        {
            /* Check the execWriteFlag before execute or cancel write long operation */
            if(eventParam->execWriteFlag == CYBLE_GATT_EXECUTE_WRITE_EXEC_FLAG)
            {
                locCharValue[locCharIndex].gattErrorCode = CYBLE_GATT_ERR_NONE;
                locCharValue[locCharIndex].connHandle = eventParam->connHandle;
                locCharValue[locCharIndex].charIndex = locCharIndex;
                locCharValue[locCharIndex].value = &locGattValue[locCharIndex];
            
                CyBle_OtsApplCallback((uint32)CYBLE_EVT_OTSS_WRITE_CHAR, &locCharValue[locCharIndex]);

                CYBLE_GATT_DB_ATTR_SET_ATTR_GEN_LEN(cyBle_otss.charInfo[locCharIndex].charHandle,
                                                            locGattValue[locCharIndex].len);    
            }
            
            /* Indicate that request was handled */
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
    }
}

/******************************************************************************
* Function Name: CyBle_OtssSetCharacteristicValue
***************************************************************************//**
* 
*  Sets the characteristic value of the service in the local database.
* 
*  \param charIndex: The index of the service characteristic. Starts with zero.
*  \param attrSize:  The size (in bytes) of the characteristic value attribute.
*  \param attrValue: The pointer to the characteristic value data that should 
*                    be stored in the GATT database.
* 
* \return
*  A return value is of type CYBLE_API_RESULT_T.
*  * CYBLE_ERROR_OK - The request handled successfully.
*  * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameter failed.
*  * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - An optional characteristic is
*                                              absent.
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtssSetCharacteristicValue(CYBLE_OTS_CHAR_INDEX_T charIndex,
    uint8 attrSize, uint8 *attrValue)
{
    CYBLE_API_RESULT_T apiResult = CYBLE_ERROR_OK;

    if(charIndex >= CYBLE_OTS_CHAR_COUNT)
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
    else if(CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE == cyBle_otss.charInfo[charIndex].charHandle)
    {
        apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
    }
    else
    {
        CYBLE_GATT_HANDLE_VALUE_PAIR_T locHandleValuePair;
        
        /* Store characteristic value into GATT database */
        locHandleValuePair.attrHandle = cyBle_otss.charInfo[charIndex].charHandle;
        locHandleValuePair.value.len = attrSize;
        locHandleValuePair.value.val = attrValue;
        
        if(CYBLE_GATT_ERR_NONE != CyBle_GattsWriteAttributeValue(&locHandleValuePair,
                                    0u, NULL, CYBLE_GATT_DB_LOCALLY_INITIATED))
        {
            apiResult = CYBLE_ERROR_INVALID_PARAMETER;
        }
    }

    return (apiResult);
}

/******************************************************************************
* Function Name: CyBle_OtssGetCharacteristicValue
***************************************************************************//**
* 
*  Gets the characteristic value of the service, which is a value identified by
*  charIndex.
* 
*  \param charIndex: The index of the service characteristic. Starts with zero.
*  \param attrSize:  The size of the characteristic value attribute.
*  \param attrValue: The pointer to the location where characteristic value 
*                    data should be stored.
* 
* \return
*  A return value is of type CYBLE_API_RESULT_T.
*  * CYBLE_ERROR_OK - The request handled successfully
*  * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameter failed.
*  * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - An optional characteristic is
*                                              absent.
*
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtssGetCharacteristicValue(CYBLE_OTS_CHAR_INDEX_T charIndex, uint8 attrSize, uint8 *attrValue)
{
    CYBLE_API_RESULT_T apiResult;
    
    /* Check parameters */
    if(charIndex >= CYBLE_OTS_CHAR_COUNT)
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
	else if(CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE == cyBle_otss.charInfo[charIndex].charHandle)
    {
        apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
    }
    else
    {
        CYBLE_GATT_HANDLE_VALUE_PAIR_T locHandleValuePair;
        
        /* Get characteristic value from GATT database */
        locHandleValuePair.attrHandle = cyBle_otss.charInfo[charIndex].charHandle;
        locHandleValuePair.value.len = attrSize;
        locHandleValuePair.value.val = attrValue;
        
        if(CYBLE_GATT_ERR_NONE != CyBle_GattsReadAttributeValue(&locHandleValuePair,
                                    0u, CYBLE_GATT_DB_LOCALLY_INITIATED))
        {
            apiResult = CYBLE_ERROR_INVALID_PARAMETER;
        }
        else
        {
            apiResult = CYBLE_ERROR_OK;
        }
    }

    return (apiResult);
}

/******************************************************************************
* Function Name: CyBle_OtssGetCharacteristicDescriptor
***************************************************************************//**
* 
*  Gets a characteristic descriptor of a specified characteristic of the Object 
*  Transfer Service from the local GATT database.
* 
*  \param charIndex:  The index of the characteristic.
*  \param descrIndex: The index of the characteristic descriptor.
*  \param attrSize:   The size of the characteristic descriptor attribute.
*  \param attrValue:  The pointer to the location where characteristic 
*                     descriptor value data should be stored.
* 
* \return
*  Return value is of type CYBLE_API_RESULT_T.
*  * CYBLE_ERROR_OK - The request handled successfully
*  * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameter failed.
*  * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - Optional descriptor is absent.
*
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtssGetCharacteristicDescriptor(CYBLE_OTS_CHAR_INDEX_T charIndex, 
                     CYBLE_OTS_DESCR_INDEX_T descrIndex, uint8 attrSize, uint8 *attrValue)
{
    CYBLE_API_RESULT_T apiResult = CYBLE_ERROR_OK;
    
    /* Check parameters */
    if((charIndex >= CYBLE_OTS_CHAR_COUNT) || (descrIndex >= CYBLE_OTS_DESCR_COUNT))
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
	else if(CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE == cyBle_otss.charInfo[charIndex].descrHandle[descrIndex])
    {
        apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
    }
    else
    {
        CYBLE_GATT_HANDLE_VALUE_PAIR_T locHandleValuePair;
        
        /* Get data from database */
        locHandleValuePair.attrHandle = cyBle_otss.charInfo[charIndex].descrHandle[descrIndex];
        locHandleValuePair.value.len = attrSize;
        locHandleValuePair.value.val = attrValue;

        if(CYBLE_GATT_ERR_NONE != CyBle_GattsReadAttributeValue(&locHandleValuePair,
                                    0u, CYBLE_GATT_DB_LOCALLY_INITIATED))
        {
            apiResult = CYBLE_ERROR_INVALID_PARAMETER;
        }
    }

    return (apiResult);
}

/******************************************************************************
* Function Name: CyBle_OtssSetCharacteristicDescriptor
***************************************************************************//**
* 
*  Set a characteristic descriptor of a specified characteristic of the Object 
*  Transfer Service from the local GATT database.
* 
*  \param charIndex:  The index of the characteristic.
*  \param descrIndex: The index of the characteristic descriptor.
*  \param attrSize:   The size of the characteristic descriptor attribute.
*  \param attrValue:  The pointer to the descriptor value data to 
*                     be stored in the GATT database.
* 
* \return
*  Return value is of type CYBLE_API_RESULT_T.
*  * CYBLE_ERROR_OK - The request handled successfully.
*  * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameter failed.
*  * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - Optional descriptor is absent.
*
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtssSetCharacteristicDescriptor(CYBLE_OTS_CHAR_INDEX_T charIndex, 
                  CYBLE_OTS_DESCR_INDEX_T descrIndex, uint8 attrSize, uint8 *attrValue)
{
    CYBLE_API_RESULT_T apiResult = CYBLE_ERROR_OK;
    
    /* Check parameters */
    if((charIndex >= CYBLE_OTS_CHAR_COUNT) || (descrIndex >= CYBLE_OTS_DESCR_COUNT))
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
	else if(CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE == cyBle_otss.charInfo[charIndex].descrHandle[descrIndex])
    {
        apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
    }
    else
    {
        CYBLE_GATT_HANDLE_VALUE_PAIR_T locHandleValuePair;
        
        /* Store characteristic descriptor value into GATT database */
        locHandleValuePair.attrHandle = cyBle_otss.charInfo[charIndex].descrHandle[descrIndex];
        locHandleValuePair.value.len = attrSize;
        locHandleValuePair.value.val = attrValue;

        if(CYBLE_GATT_ERR_NONE != CyBle_GattsWriteAttributeValue(&locHandleValuePair, 
                                            0u, NULL, CYBLE_GATT_DB_LOCALLY_INITIATED))
        {
            apiResult = CYBLE_ERROR_INVALID_PARAMETER;
        }
    }

    return (apiResult);
}


/******************************************************************************
* Function Name: CyBle_OtssSendIndication
***************************************************************************//**
* 
*  Sends an indication with a characteristic value of the Object Transfer 
*  Service, which is a value specified by charIndex, to the client's device.
*  
*  On enabling indication successfully it sends out a 'Handle Value Indication' 
*  which results in CYBLE_EVT_OTSS_INDICATION or 
*  CYBLE_EVT_GATTC_HANDLE_VALUE_IND (if service specific callback function is
*  not registered) event at the GATT Client's end.
*
*  \param connHandle:   The connection handle.
*  \param charIndex:    The index of the service characteristic.
*  \param attrSize:     The size of the characteristic value attribute.
*  \param attrValue:    The pointer to the characteristic value data that 
*                       should be sent to the client's device.
* 
* \return
*  A return value is of type CYBLE_API_RESULT_T.
*   * CYBLE_ERROR_OK - The request handled successfully.
*   * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameter failed.
*   * CYBLE_ERROR_INVALID_OPERATION - This operation is not permitted.
*   * CYBLE_ERROR_INVALID_STATE - Connection with the client is not established.
*   * CYBLE_ERROR_MEMORY_ALLOCATION_FAILED - Memory allocation failed.
*   * CYBLE_ERROR_IND_DISABLED - Indication is not enabled by the client.
*   * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - An optional characteristic is
*                                               absent.
*
* \events
*  In case of successful execution (return value = CYBLE_ERROR_OK)
*  the next events can appear: \n
*   If the OTS service-specific callback is registered 
*      (with CyBle_OtsRegisterAttrCallback):
*  * CYBLE_EVT_OTSS_INDICATION_CONFIRMED -In case if the indication is
*                                successfully delivered to the peer device.
*  .
*   Otherwise (if the OTS service-specific callback is not registered):
*  * CYBLE_EVT_GATTS_HANDLE_VALUE_CNF - In case if the indication is
*                                successfully delivered to the peer device.
*
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtssSendIndication(CYBLE_CONN_HANDLE_T connHandle,
    CYBLE_OTS_CHAR_INDEX_T charIndex, uint8 attrSize, uint8 *attrValue)
{
    /* Store new data in database */
    CYBLE_API_RESULT_T apiResult = CYBLE_ERROR_OK;
    
    /* Send indication if it is enabled and connected */
    if(charIndex >= CYBLE_OTS_CHAR_COUNT)
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
    else if(CYBLE_STATE_CONNECTED != CyBle_GetState())
    {
        apiResult = CYBLE_ERROR_INVALID_STATE;
    }
    else if(!CYBLE_IS_INDICATION_ENABLED(
        cyBle_otss.charInfo[charIndex].descrHandle[CYBLE_OTS_CCCD]))
    {
        apiResult = CYBLE_ERROR_IND_DISABLED;
    }
    else
    {
        if(cyBle_otss.charInfo[charIndex].charHandle != CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
        {
            CYBLE_GATTS_HANDLE_VALUE_IND_T indReqParam;

            /* Fill all fields of write request structure ... */
            indReqParam.attrHandle = cyBle_otss.charInfo[charIndex].charHandle;
            indReqParam.value.val = attrValue;
            indReqParam.value.len = attrSize;

            /* Send indication to client using previously filled structure */
            apiResult = CyBle_GattsIndication(connHandle, &indReqParam);
            /* Save handle to support service specific value confirmation response from client */
            if(apiResult == CYBLE_ERROR_OK)
            {
                cyBle_otssReqHandle = indReqParam.attrHandle;
            }
        }
        else
        {
            apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
        }
    }
    return (apiResult);
}


/******************************************************************************
* Function Name: CyBle_OtssConfirmationEventHandler
***************************************************************************//**
* 
*  Handles a Value Confirmation request event from the BLE stack.
* 
*  eventParam - The pointer to a structure of type CYBLE_CONN_HANDLE_T.
*  
******************************************************************************/
void CyBle_OtssConfirmationEventHandler(const CYBLE_CONN_HANDLE_T *eventParam)
{
    CYBLE_OTS_CHAR_INDEX_T locCharIndex;
    CYBLE_OTS_CHAR_VALUE_T locCharValue;
    uint8 locReqHandle = 0u;

    if((CyBle_OtsApplCallback != NULL) && (cyBle_otssReqHandle != CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE))
    {
        for(locCharIndex = CYBLE_OTS_FEATURE; (locCharIndex < CYBLE_OTS_CHAR_COUNT) && (locReqHandle == 0u); 
            locCharIndex++)
        {
            if(cyBle_otssReqHandle == cyBle_otss.charInfo[locCharIndex].charHandle)
            {
                locCharValue.connHandle = *eventParam;
                locCharValue.charIndex = locCharIndex;
                locCharValue.value = NULL;
                cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
                cyBle_otssReqHandle = CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE;
                CyBle_OtsApplCallback((uint32)CYBLE_EVT_OTSS_INDICATION_CONFIRMED, &locCharValue);
                locReqHandle = 1u;
            }
        }
    }
}


/******************************************************************************
* Function Name: CyBle_OtsGet32ByPtr
***************************************************************************//**
* 
*  Returns a four-byte value by using a pointer to the LSB.
* 
*  \param ptr: The pointer to the LSB of four-byte value (little-endian).
* 
* \return
*  uint32 value: Four-byte value.
* 
******************************************************************************/
uint32 CyBle_OtsGet32ByPtr(const uint8 ptr[])
{
    return (((uint32) ptr[0u]) | ((uint32) (((uint32) ptr[1u]) << 8u)) | ((uint32)((uint32) ptr[2u]) << 16u) |
        ((uint32)((uint32) ptr[3u]) << 24u));
}

#endif /* CYBLE_OTS_SERVER */

#ifdef CYBLE_OTS_CLIENT
         
    
/******************************************************************************
* Function Name: CyBle_OtscSetCharacteristicValue
***************************************************************************//**
* 
*  This function is used to write the characteristic (which is identified by
*  charIndex) value attribute in the server. As a result a Write Request is 
*  sent to the GATT Server and on successful execution of the request on the 
*  Server side the CYBLE_EVT_OTSS_WRITE_CHAR events is generated.
*  On successful request execution on the Server side the Write Response is 
*  sent to the Client.
* 
*  The Write Response just confirms the operation success.
* 
*  \param connHandle: The connection handle.
*  \param charIndex:  The index of the service characteristic.
*  \param attrSize:   The size of the characteristic value attribute.
*  \param attrValue:  The pointer to the characteristic value data that should 
*                     be sent to the server device.
* 
* \return
*  A return value is of type CYBLE_API_RESULT_T.
*  * CYBLE_ERROR_OK - The request was sent successfully.
*  * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameters failed.
*  * CYBLE_ERROR_MEMORY_ALLOCATION_FAILED - Memory allocation failed.
*  * CYBLE_ERROR_INVALID_STATE - Connection with the server is not established.
*  * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - The peer device doesn't have
*                                              the particular characteristic.
*  * CYBLE_ERROR_INVALID_OPERATION - Operation is invalid for this
*                                    characteristic.
*
* \events
*  In the case of successful execution (return value = CYBLE_ERROR_OK)
*  the next events can appear: \n
*   If the OTS service-specific callback is registered 
*      (with CyBle_OtsRegisterAttrCallback):
*  * CYBLE_EVT_OTSC_WRITE_CHAR_RESPONSE - If the requested attribute is
*                                successfully written on the peer device,
*                                the details (char index, etc.) are 
*                                provided with an event parameter structure
*                                of type CYBLE_OTS_CHAR_VALUE_T.
*  .
*  Otherwise (if the OTS service-specific callback is not registered):
*  * CYBLE_EVT_GATTC_WRITE_RSP - If the requested attribute is 
*                                successfully written on the peer device.
*  * CYBLE_EVT_GATTC_EXEC_WRITE_RSP - If the requested attribute is 
*                                successfully written on the peer device.
*  * CYBLE_EVT_GATTC_ERROR_RSP - If there is some trouble with the 
*                                requested attribute on the peer device,
*                                the details are provided with an event parameter
*                                structure (CYBLE_GATTC_ERR_RSP_PARAM_T).
*
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtscSetCharacteristicValue(CYBLE_CONN_HANDLE_T connHandle,
                                                        CYBLE_OTS_CHAR_INDEX_T charIndex,
                                                            uint8 attrSize, uint8 * attrValue)
{
    CYBLE_API_RESULT_T apiResult;
    uint16 locMtu = CYBLE_GATT_MTU;
    (void) CyBle_GattGetMtuSize(&locMtu);
    
    /* Check parameters */
    if(CyBle_GetClientState() != CYBLE_CLIENT_STATE_DISCOVERED)
    {
        apiResult = CYBLE_ERROR_INVALID_STATE;
    }
    else if(charIndex >= CYBLE_OTS_CHAR_COUNT)
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
	else if(cyBle_otsc.charInfo[charIndex].valueHandle == CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
    {
		apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
	}
    else if((CYBLE_CHAR_PROP_WRITE & cyBle_otsc.charInfo[charIndex].properties) == 0u)
    {
        apiResult = CYBLE_ERROR_INVALID_OPERATION;
    }
    else if((locMtu - 3u) < attrSize)
    {
        CYBLE_GATTC_PREP_WRITE_REQ_T prepWriteReqParam;
        
        prepWriteReqParam.handleValuePair.attrHandle = cyBle_otsc.charInfo[charIndex].valueHandle;
        prepWriteReqParam.offset = 0u;
        prepWriteReqParam.handleValuePair.value.val = attrValue;
        prepWriteReqParam.handleValuePair.value.len = attrSize;   
        
        apiResult = CyBle_GattcWriteLongCharacteristicValues(connHandle, &prepWriteReqParam);
        
        if(apiResult == CYBLE_ERROR_OK)
        {
            cyBle_otscReqHandle = cyBle_otsc.charInfo[charIndex].valueHandle;
        }
    }
    else 
    {
        CYBLE_GATTC_WRITE_REQ_T writeReqParam;
        
        writeReqParam.attrHandle = cyBle_otsc.charInfo[charIndex].valueHandle;
        writeReqParam.value.val = attrValue;
        writeReqParam.value.len = attrSize;

        apiResult = CyBle_GattcWriteCharacteristicValue(connHandle, &writeReqParam);
        if(apiResult == CYBLE_ERROR_OK)
        {
            cyBle_otscReqHandle = cyBle_otsc.charInfo[charIndex].valueHandle;
        }
    }

    return (apiResult);
}


/******************************************************************************
* Function Name: CyBle_OtscSetLongCharacteristicValue
***************************************************************************//**
* 
*  Sends a request to set a long characteristic value of the service, which is
*  a value identified by charIndex, to the server's device.
* 
*  \param connHandle: The connection handle.
*  \param charIndex:  The index of the service characteristic. Starts with zero.
*  \param attrSize:   The size of the characteristic value attribute.
*  \param attrValue:  The pointer to the characteristic value data that should be
*                     sent to the server device.
* 
* \return
*  A return value is of type CYBLE_API_RESULT_T.
*  * CYBLE_ERROR_OK - The request was sent successfully.
*  * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameters failed.
*  * CYBLE_ERROR_MEMORY_ALLOCATION_FAILED - Memory allocation failed.
*  * CYBLE_ERROR_INVALID_STATE - Connection with the server is not established.
*  * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - The peer device doesn't have
*                                              the particular characteristic.
*  * CYBLE_ERROR_INVALID_OPERATION - Operation is invalid for this
*                                    characteristic.
*
* \events
*  In case of successful execution (return value = CYBLE_ERROR_OK)
*  the next events can appear: \n
*   If the OTS service-specific callback is registered 
*      (with CyBle_OtsRegisterAttrCallback):
*  * CYBLE_EVT_OTSC_WRITE_CHAR_RESPONSE - In case if the requested attribute is
*                                successfully wrote on the peer device,
*                                the details (char index, etc.) are 
*                                provided with event parameter structure
*                                of type CYBLE_OTS_CHAR_VALUE_T.
*
*   Otherwise (if the OTS service-specific callback is not registered):
*  * CYBLE_EVT_GATTC_EXEC_WRITE_RSP - In case if the requested attribute is 
*                                successfully wrote on the peer device.
*  * CYBLE_EVT_GATTC_ERROR_RSP - In case if there some trouble with the 
*                                requested attribute on the peer device,
*                                the details are provided with event parameters 
*                                structure (CYBLE_GATTC_ERR_RSP_PARAM_T).
*
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtscSetLongCharacteristicValue(CYBLE_CONN_HANDLE_T connHandle, CYBLE_OTS_CHAR_INDEX_T charIndex,
    uint16 attrSize, uint8 *attrValue)
{
    CYBLE_API_RESULT_T apiResult;
    CYBLE_GATTC_PREP_WRITE_REQ_T writeReqParam;

    if(CyBle_GetClientState() != CYBLE_CLIENT_STATE_DISCOVERED)
    {
        apiResult = CYBLE_ERROR_INVALID_STATE;
    }
    else if(charIndex >= CYBLE_OTS_CHAR_COUNT)
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
    else if(cyBle_otsc.charInfo[charIndex].valueHandle == CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
    {
        apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
    }
    else
    {
        writeReqParam.handleValuePair.attrHandle = cyBle_otsc.charInfo[charIndex].valueHandle;
        writeReqParam.handleValuePair.value.val = attrValue;
        writeReqParam.handleValuePair.value.len = attrSize;
        writeReqParam.offset = 0u;

        /* ... and send request to server's device. */
        apiResult = CyBle_GattcWriteLongCharacteristicValues(connHandle, &writeReqParam);

        /* Save handle to support service specific write response from device */
        if(apiResult == CYBLE_ERROR_OK)
        {
            cyBle_otscReqHandle = writeReqParam.handleValuePair.attrHandle;
        }
    }

    return (apiResult);
}

/******************************************************************************
* Function Name: CyBle_OtscGetCharacteristicValue
***************************************************************************//**
* 
*  This function is used to read the characteristic Value from a server,
*  as identified by its charIndex
* 
*  The Read Response returns the characteristic Value in the Attribute Value
*  parameter.
* 
*  \param connHandle: The connection handle.
*  \param charIndex:  The index of the service characteristic.
* 
* \return
*  A return value is of type CYBLE_API_RESULT_T.
*  * CYBLE_ERROR_OK - The read request was sent successfully.  
*  * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameters failed.
*  * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - The peer device doesn't have
*                                              the particular characteristic.
*  * CYBLE_ERROR_MEMORY_ALLOCATION_FAILED - Memory allocation failed.
*  * CYBLE_ERROR_INVALID_STATE - Connection with the server is not established.
*  * CYBLE_ERROR_INVALID_OPERATION - Operation is invalid for this 
*                                    characteristic.
*
* \events
*  In case of successful execution (return value = CYBLE_ERROR_OK)
*  the next events can appear: \n
*   If the OTS service-specific callback is registered 
*      (with CyBle_OtsRegisterAttrCallback):
*  * CYBLE_EVT_OTSC_READ_CHAR_RESPONSE - If the requested attribute is
*                                successfully written on the peer device,
*                                the details (char index , value, etc.) are 
*                                provided with an event parameter structure
*                                of type CYBLE_OTS_CHAR_VALUE_T.
*  .
*   Otherwise (if the OTS service-specific callback is not registered):
*  * CYBLE_EVT_GATTC_READ_RSP - If the requested attribute is 
*                                successfully read on the peer device,
*                                the details (handle, value, etc.) are 
*                                provided with an event parameter
*                                structure (CYBLE_GATTC_READ_RSP_PARAM_T).
*  * CYBLE_EVT_GATTC_ERROR_RSP - If there is some trouble with the 
*                                requested attribute on the peer device,
*                                the details are provided with an event parameter
*                                structure (CYBLE_GATTC_ERR_RSP_PARAM_T).
*
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtscGetCharacteristicValue(CYBLE_CONN_HANDLE_T connHandle, CYBLE_OTS_CHAR_INDEX_T charIndex)
{
    CYBLE_API_RESULT_T apiResult;

    /* Check parameters */
    if(CyBle_GetClientState() != CYBLE_CLIENT_STATE_DISCOVERED)
    {
        apiResult = CYBLE_ERROR_INVALID_STATE;
    }
    else if(charIndex >= CYBLE_OTS_CHAR_COUNT)
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
	else if(cyBle_otsc.charInfo[charIndex].valueHandle == CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
    {
		apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
	}
    else if((CYBLE_CHAR_PROP_READ & cyBle_otsc.charInfo[charIndex].properties) == 0u)
    {
        apiResult = CYBLE_ERROR_INVALID_OPERATION;
    }
    else
    {
        apiResult = CyBle_GattcReadCharacteristicValue(connHandle, cyBle_otsc.charInfo[charIndex].valueHandle);
    }
    
    if(apiResult == CYBLE_ERROR_OK)
    {
        cyBle_otscReqHandle = cyBle_otsc.charInfo[charIndex].valueHandle;
    }

    return (apiResult);
}


/******************************************************************************
* Function Name: CyBle_OtscGetLongCharacteristicValue
***************************************************************************//**
* 
*  Sends a request to read a long characteristic.
* 
*  \param connHandle: The connection handle.
*  \param charIndex:  The index of the service characteristic.
*  \param attrSize:   The size of the characteristic value attribute.
*  \param attrValue:  The pointer to the buffer where the read long characteristic 
*                     descriptor value should be stored.
* 
* \return
*  A return value is of type CYBLE_API_RESULT_T.
*  * CYBLE_ERROR_OK - The read request was sent successfully.
*  * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameters failed.
*  * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - The peer device doesn't have
*                                              the particular characteristic.
*  * CYBLE_ERROR_MEMORY_ALLOCATION_FAILED - Memory allocation failed.
*  * CYBLE_ERROR_INVALID_STATE - Connection with the server is not established.
*  * CYBLE_ERROR_INVALID_OPERATION - Operation is invalid for this 
*                                    characteristic
*
* \events
*  In the case of successful execution (return value = CYBLE_ERROR_OK)
*  the next events can appear: \n
*   If the OTS service-specific callback is registered 
*      (with CyBle_OtsRegisterAttrCallback):
*  * CYBLE_EVT_OTSC_READ_CHAR_RESPONSE - If the requested attribute is
*                                successfully written on the peer device,
*                                the details (char index , value, etc.) are 
*                                provided with an event parameter structure
*                                of type CYBLE_OTS_CHAR_VALUE_T.
*  .
*   Otherwise (if the OTS service-specific callback is not registered):
*  * CYBLE_EVT_GATTC_READ_BLOB_RSP - If the requested attribute is 
*                                successfully read on the peer device,
*                                the details (handle, value, etc.) are 
*                                provided with an event parameter
*                                structure (CYBLE_GATTC_READ_RSP_PARAM_T).
*  * CYBLE_EVT_GATTC_ERROR_RSP - If there is some trouble with the 
*                                requested attribute on the peer device,
*                                the details are provided with an event parameter
*                                structure (CYBLE_GATTC_ERR_RSP_PARAM_T).
*
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtscGetLongCharacteristicValue(CYBLE_CONN_HANDLE_T connHandle, CYBLE_OTS_CHAR_INDEX_T charIndex, 
                                                        uint16 attrSize,
                                                        uint8 *attrValue)
{
    CYBLE_API_RESULT_T apiResult;

    /* Check parameters */
    if(CyBle_GetClientState() != CYBLE_CLIENT_STATE_DISCOVERED)
    {
        apiResult = CYBLE_ERROR_INVALID_STATE;
    }
    else if((attrSize == 0u) || (attrValue == NULL))
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
	else if(cyBle_otsc.charInfo[charIndex].valueHandle == CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
    {
		apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
	}
    else if((CYBLE_CHAR_PROP_READ & cyBle_otsc.charInfo[charIndex].properties) == 0u)
    {
        apiResult = CYBLE_ERROR_INVALID_OPERATION;
    }
    else
    {
        CYBLE_GATTC_READ_BLOB_REQ_T	readBlobReqParam;
        readBlobReqParam.attrHandle = cyBle_otsc.charInfo[charIndex].valueHandle;
        readBlobReqParam.offset = 0u;
        
        apiResult = CyBle_GattcReadLongCharacteristicValues(connHandle, &readBlobReqParam);
    }
    
    if(apiResult == CYBLE_ERROR_OK)
    {
        cyBle_otscReqHandle = cyBle_otsc.charInfo[charIndex].valueHandle;
        cyBle_otscRdLongBuffLen = attrSize;
        cyBle_otscRdLongBuffPtr = attrValue;
        cyBle_otscCurrLen = 0u;
    }

    return (apiResult);
}


/******************************************************************************
* Function Name: CyBle_OtscSetCharacteristicDescriptor
***************************************************************************//**
* 
*  This function is used to write the characteristic Value to the server,
*  as identified by its charIndex.
* 
*  \param connHandle: The connection handle.
*  \param charIndex:  The index of the service characteristic.
*  \param descrIndex: The index of the service characteristic descriptor.
*  \param attrSize:   The size of the characteristic descriptor value 
*                     attribute.
*  \param attrValue:  The pointer to the characteristic descriptor value data
*                     type should be sent to the server device.
*
* \return
*  A return value is of type CYBLE_API_RESULT_T.
*  * CYBLE_ERROR_OK - The request was sent successfully.
*  * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameters failed.
*  * CYBLE_ERROR_INVALID_STATE - The state is not valid.
*  * CYBLE_ERROR_MEMORY_ALLOCATION_FAILED - Memory allocation failed.
*  * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - The peer device doesn't have
*                                              the particular characteristic.
*  * CYBLE_ERROR_INVALID_OPERATION - This operation is not permitted on 
*                                    the specified attribute
*
* \events
*  In the case of successful execution (return value = CYBLE_ERROR_OK)
*  the next events can appear: \n
*   If the OTS service-specific callback is registered 
*      (with CyBle_OtsRegisterAttrCallback):
*  * CYBLE_EVT_OTSC_WRITE_DESCR_RESPONSE - If the requested attribute is
*                                successfully written on the peer device,
*                                the details (char index, descr index etc.) are
*                                provided with an event parameter structure
*                                of type CYBLE_OTS_DESCR_VALUE_T.
*  .
*   Otherwise (if the OTS service-specific callback is not registered):
*  * CYBLE_EVT_GATTC_WRITE_RSP - If the requested attribute is 
*                                successfully written on the peer device.
*  * CYBLE_EVT_GATTC_ERROR_RSP - If there is some trouble with the 
*                                requested attribute on the peer device,
*                                the details are provided with an event parameter
*                                structure (CYBLE_GATTC_ERR_RSP_PARAM_T).
*
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtscSetCharacteristicDescriptor(CYBLE_CONN_HANDLE_T connHandle,
    CYBLE_OTS_CHAR_INDEX_T charIndex, CYBLE_OTS_DESCR_INDEX_T descrIndex, uint8 attrSize, uint8 * attrValue)
{
    CYBLE_API_RESULT_T apiResult;
    
    /* Check parameters */
    if(CyBle_GetClientState() != CYBLE_CLIENT_STATE_DISCOVERED)
    {
        apiResult = CYBLE_ERROR_INVALID_STATE;
    }
    else if((charIndex >= CYBLE_OTS_CHAR_COUNT)
         || (descrIndex >= CYBLE_OTS_DESCR_COUNT)
         || (attrSize != CYBLE_CCCD_LEN))
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
    else if(cyBle_otsc.charInfo[charIndex].descrHandle[descrIndex] == CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
    {
		apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
	}
    else
    {
        CYBLE_GATTC_WRITE_REQ_T writeReqParam;
        
        /* Fill all fields of write request structure ... */
        writeReqParam.attrHandle = cyBle_otsc.charInfo[charIndex].descrHandle[descrIndex];
        writeReqParam.value.val = attrValue;
        writeReqParam.value.len = CYBLE_CCCD_LEN;

        /* ... and send request to server device. */
        apiResult = CyBle_GattcWriteCharacteristicDescriptors(connHandle, &writeReqParam);
        if(apiResult == CYBLE_ERROR_OK)
        {
            /* Save handle to support service specific read response from device */
            cyBle_otscReqHandle = writeReqParam.attrHandle;
        }
    }

    return (apiResult);
}


/******************************************************************************
* Function Name: CyBle_OtscGetCharacteristicDescriptor
***************************************************************************//**
* 
*  Gets the characteristic descriptor of the specified characteristic.
* 
*  \param connHandle: The connection handle.
*  \param charIndex:  The index of the service characteristic.
*  \param descrIndex: The index of the service characteristic descriptor.
* 
* \return
*  A return value is of type CYBLE_API_RESULT_T.
*  * CYBLE_ERROR_OK - The request was sent successfully.
*  * CYBLE_ERROR_INVALID_PARAMETER - Validation of the input parameters failed.
*  * CYBLE_ERROR_INVALID_STATE - The state is not valid.
*  * CYBLE_ERROR_MEMORY_ALLOCATION_FAILED - Memory allocation failed.
*  * CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE - The peer device doesn't have
*                                              the particular descriptor.
*  * CYBLE_ERROR_INVALID_OPERATION - This operation is not permitted on 
*                                    the specified attribute.
*
* \events
*  In the case of successful execution (return value = CYBLE_ERROR_OK)
*  the next events can appear: \n
*  If the OTS service-specific callback is registered 
*      (with CyBle_OtsRegisterAttrCallback):
*  * CYBLE_EVT_OTSC_READ_DESCR_RESPONSE - If the requested attribute is
*                                successfully written on the peer device,
*                                the details (char index, descr index, value, etc.) 
*                                are provided with an event parameter structure
*                                of type CYBLE_OTS_DESCR_VALUE_T. 
*  .
*  Otherwise (if the OTS service-specific callback is not registered):
*  * CYBLE_EVT_GATTC_READ_RSP - If the requested attribute is 
*                                successfully read on the peer device,
*                                the details (handle, value, etc.) are 
*                                provided with an event parameter
*                                structure (CYBLE_GATTC_READ_RSP_PARAM_T).
*  * CYBLE_EVT_GATTC_ERROR_RSP - If there is some trouble with the 
*                                requested attribute on the peer device,
*                                the details are provided with an event parameter
*                                structure (CYBLE_GATTC_ERR_RSP_PARAM_T).
*
******************************************************************************/
CYBLE_API_RESULT_T CyBle_OtscGetCharacteristicDescriptor(CYBLE_CONN_HANDLE_T connHandle,
                       CYBLE_OTS_CHAR_INDEX_T charIndex, CYBLE_OTS_DESCR_INDEX_T descrIndex)
{
    CYBLE_API_RESULT_T apiResult;
    
    /* Check parameters */
    if(CyBle_GetClientState() != CYBLE_CLIENT_STATE_DISCOVERED)
    {
        apiResult = CYBLE_ERROR_INVALID_STATE;
    }
    else if((charIndex >= CYBLE_OTS_CHAR_COUNT) || (descrIndex >= CYBLE_OTS_DESCR_COUNT))
    {
        apiResult = CYBLE_ERROR_INVALID_PARAMETER;
    }
    else if(cyBle_otsc.charInfo[charIndex].descrHandle[descrIndex] == CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
    {
		apiResult = CYBLE_ERROR_GATT_DB_INVALID_ATTR_HANDLE;
	}
    else
    {
        apiResult = CyBle_GattcReadCharacteristicDescriptors(connHandle, cyBle_otsc.charInfo[charIndex].descrHandle[descrIndex]);
        if(apiResult == CYBLE_ERROR_OK)
        {
            cyBle_otscReqHandle = cyBle_otsc.charInfo[charIndex].descrHandle[descrIndex];
        }
    }
    
    return (apiResult);
}


/******************************************************************************
* Function Name: CyBle_OtscDiscoverCharacteristicsEventHandler
***************************************************************************//**
* 
*  This function is called on receiving a CYBLE_EVT_GATTC_READ_BY_TYPE_RSP
*  event. Based on the service UUID, an appropriate data structure is populated
*  using the data received as part of the callback.
* 
*  \param discCharInfo: The pointer to a characteristic information structure.
* 
******************************************************************************/
void CyBle_OtscDiscoverCharacteristicsEventHandler(CYBLE_DISC_CHAR_INFO_T *discCharInfo)
{
    /* Object Transfer Service characteristics UUIDs */
    static const CYBLE_UUID16 cyBle_otscCharUuid[CYBLE_OTS_CHAR_COUNT] =
    {
        CYBLE_UUID_CHAR_OBJECT_FEATURE,                /**< Exposes which optional features are supported by the Server implementation.*/
        CYBLE_UUID_CHAR_OBJECT_NAME,                   /**< The name of the Current Object. */
        CYBLE_UUID_CHAR_OBJECT_TYPE,                   /**< The type of the Current Object, identifying the object type by UUID. */
        CYBLE_UUID_CHAR_OBJECT_SIZE,                   /**< The current size as well as the allocated size of the Current Object. */
        CYBLE_UUID_CHAR_OBJECT_FIRST_CREATED,          /**< Date and time when the object contents were first created. */
        CYBLE_UUID_CHAR_OBJECT_LAST_MODIFIED,          /**< Date and time when the object content was last modified. */
        CYBLE_UUID_CHAR_OBJECT_ID,                     /**< The Object ID of the Current Object. The Object ID is a LUID (Locally Unique Identifier). */
        CYBLE_UUID_CHAR_OBJECT_PROPERTIES,             /**< The properties of the Current Object. */
        CYBLE_UUID_CHAR_OBJECT_ACTION_CONTROL_POINT,   /**< Is used by a Client to control certain behaviors of the Server. */
        CYBLE_UUID_CHAR_OBJECT_LIST_CONTROL_POINT,     /**< Provides a mechanism for the Client to find the desired object and to designate it as the Current Object. */
        CYBLE_UUID_CHAR_OBJECT_LIST_FILTER,            /**< The filter conditions determines which objects are included in or excluded from the list of objects.*/
        CYBLE_UUID_CHAR_OBJECT_LIST_FILTER,            /**< The filter conditions determines which objects are included in or excluded from the list of objects.*/
        CYBLE_UUID_CHAR_OBJECT_LIST_FILTER,            /**< The filter conditions determines which objects are included in or excluded from the list of objects.*/
        CYBLE_UUID_CHAR_OBJECT_CHANGED                 /**< Enables a Client to receive an indication if the contents and/or metadata of one or more objects are changed.*/
    };

    static CYBLE_GATT_DB_ATTR_HANDLE_T *otsLastEndHandle = NULL;
    uint8 i;
    
    /* Update last characteristic endHandle to declaration handle of this characteristic */
    if(otsLastEndHandle != NULL)
    {
        *otsLastEndHandle = discCharInfo->charDeclHandle - 1u;
        otsLastEndHandle = NULL;
    }
    
    for(i = CYBLE_OTS_FEATURE; i < (uint8) CYBLE_OTS_CHAR_COUNT; i++)
    {
        if(cyBle_otscCharUuid[i] == discCharInfo->uuid.uuid16)
        {
            if(cyBle_otsc.charInfo[i].valueHandle == CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
            {
                cyBle_otsc.charInfo[i].valueHandle = discCharInfo->valueHandle;
                cyBle_otsc.charInfo[i].properties = discCharInfo->properties;
                otsLastEndHandle = &cyBle_otsc.charInfo[i].endHandle;
                break;
            }
            else
            {   
                CyBle_ApplCallback((uint32_t)CYBLE_EVT_GATTC_CHAR_DUPLICATION, &discCharInfo->uuid);
            }
        }
    }
    
    /* Init characteristic endHandle to Service endHandle.
       Characteristic endHandle will be updated to the declaration
       Handler of the following characteristic,
       in the following characteristic discovery procedure. */
    if(otsLastEndHandle != NULL)
    {
        *otsLastEndHandle = cyBle_serverInfo[CYBLE_SRVI_OTS].range.endHandle;
    }
}


/******************************************************************************
* Function Name: CyBle_OtscDiscoverCharDescriptorsEventHandler
***************************************************************************//**
* 
*  This function is called on receiving a CYBLE_EVT_GATTC_READ_BY_TYPE_RSP
*  event. Based on the service UUID, an appropriate data structure is populated
*  using the data received as part of the callback.
* 
*  \param discCharInfo: The pointer to the characteristic information structure.
* 
******************************************************************************/
void CyBle_OtscDiscoverCharDescriptorsEventHandler(CYBLE_OTS_CHAR_INDEX_T discoveryCharIndex, 
                                                   CYBLE_DISC_DESCR_INFO_T *discDescrInfo)
{
    CYBLE_OTS_DESCR_INDEX_T locDescIndex;

    if(discDescrInfo->uuid.uuid16 == CYBLE_UUID_CHAR_CLIENT_CONFIG)
    {
        locDescIndex = CYBLE_OTS_CCCD;
    }
    else    /* Not supported descriptor */
    {
        locDescIndex = CYBLE_OTS_DESCR_COUNT;
    }

    if(locDescIndex < CYBLE_OTS_DESCR_COUNT)
    {
        if(cyBle_otsc.charInfo[discoveryCharIndex].descrHandle[locDescIndex] == CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE)
        {
            cyBle_otsc.charInfo[discoveryCharIndex].descrHandle[locDescIndex] = discDescrInfo->descrHandle;
        }
        else    /* Duplication of descriptor */
        {
            CyBle_ApplCallback(CYBLE_EVT_GATTC_DESCR_DUPLICATION, &discDescrInfo->uuid);
        }
    }
}


/******************************************************************************
* Function Name: CyBle_OtscReadResponseEventHandler
***************************************************************************//**
* 
*  Handles the Read Response Event.
* 
*  \param eventParam - The pointer to the data structure.
* 
******************************************************************************/
void CyBle_OtscReadResponseEventHandler(CYBLE_GATTC_READ_RSP_PARAM_T *eventParam)
{
    uint8 locReqHandle = 0u;
    CYBLE_OTS_CHAR_INDEX_T locCharIndex;

    if((NULL != CyBle_OtsApplCallback) && (CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE != cyBle_otscReqHandle))
    {
        for(locCharIndex = CYBLE_OTS_FEATURE; (locCharIndex < CYBLE_OTS_CHAR_COUNT) && (locReqHandle == 0u); locCharIndex++)
        {
            if(cyBle_otscReqHandle == cyBle_otsc.charInfo[locCharIndex].valueHandle)
            {
                CYBLE_OTS_CHAR_VALUE_T locCharValue;
                
                locCharValue.connHandle = eventParam->connHandle;
                locCharValue.charIndex = locCharIndex;
                locCharValue.value = &eventParam->value;
                cyBle_otscReqHandle = CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE;
                CyBle_OtsApplCallback((uint32)CYBLE_EVT_OTSC_READ_CHAR_RESPONSE, &locCharValue);
                locReqHandle = 1u;
            }
            else
            {
                CYBLE_OTS_DESCR_INDEX_T locDescIndex;

                for(locDescIndex = CYBLE_OTS_CCCD; (locDescIndex < CYBLE_OTS_DESCR_COUNT) && (locReqHandle == 0u);
                    locDescIndex++)
                {
                    if(cyBle_otscReqHandle == cyBle_otsc.charInfo[locCharIndex].descrHandle[locDescIndex])
                    {
                        CYBLE_OTS_DESCR_VALUE_T locDescrValue;
                        
                        locDescrValue.connHandle = eventParam->connHandle;
                        locDescrValue.charIndex = locCharIndex;
                        locDescrValue.descrIndex = locDescIndex;
                        locDescrValue.value = &eventParam->value;
                        cyBle_otscReqHandle = CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE;
                        CyBle_OtsApplCallback((uint32)CYBLE_EVT_OTSC_READ_DESCR_RESPONSE, &locDescrValue);
                        locReqHandle = 1u;
                    }
                }
            }
        }
        if(locReqHandle != 0u)
        {
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
    }
}


/******************************************************************************
* Function Name: CyBle_OtscReadLongRespEventHandler
***************************************************************************//**
* 
*  Handles a Read Long Response event.
* 
*  \param eventParam: The pointer to the data structure specified by an event.
* 
******************************************************************************/
void CyBle_OtscReadLongRespEventHandler(const CYBLE_GATTC_READ_RSP_PARAM_T *eventParam)
{
    if((NULL != CyBle_OtsApplCallback) && (cyBle_otscReqHandle != CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE))
    {
        CYBLE_OTS_CHAR_VALUE_T locCharValue;
        CYBLE_GATT_VALUE_T locGattValue;
        
        for(locCharValue.charIndex = CYBLE_OTS_FEATURE;
            locCharValue.charIndex < CYBLE_OTS_CHAR_COUNT;
            locCharValue.charIndex++)
        {
            if(cyBle_otsc.charInfo[locCharValue.charIndex].valueHandle == cyBle_otscReqHandle)
            {
                uint8 i;
                
                /* Update user buffer with received data */
                for(i = 0u; i < eventParam->value.len; i++)
                {
                    if(cyBle_otscCurrLen < cyBle_otscRdLongBuffLen)
                    {
                        cyBle_otscRdLongBuffPtr[cyBle_otscCurrLen] = eventParam->value.val[i];
                        cyBle_otscCurrLen++;
                    }
                    else
                    {
                        CyBle_GattcStopCmd();
                        cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
                        break;
                    }
                }
                
                if((cyBle_eventHandlerFlag & CYBLE_CALLBACK) != 0u)
                {
                    uint16 mtuSize;
                    (void) CyBle_GattGetMtuSize(&mtuSize);
                    
                    /* If received data length is less than MTU size, Read Long
                    * request is completed or provided user's buffer is full.
                    */
                    locGattValue.val = cyBle_otscRdLongBuffPtr;
                    locGattValue.len = cyBle_otscCurrLen;
                    locCharValue.value = &locGattValue;
                    locCharValue.connHandle = eventParam->connHandle;
                    
                    if(((mtuSize - 1u) > eventParam->value.len))
                    {
                        CyBle_OtsApplCallback((uint32) CYBLE_EVT_OTSC_READ_CHAR_RESPONSE, &locCharValue);
                        cyBle_otscReqHandle = CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE;
                    }
                    else
                    {  
                        CyBle_OtsApplCallback((uint32) CYBLE_EVT_OTSC_READ_BLOB_RSP, &locCharValue);
                    }
                    
                    cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
                }
                
                break;
            }
        }
    }
}


/******************************************************************************
* Function Name: CyBle_OtscWriteResponseEventHandler
***************************************************************************//**
* 
*  Handles the Write Response Event.
* 
*  \param eventParam: The pointer to a data structure specified by the event.
* 
******************************************************************************/
void CyBle_OtscWriteResponseEventHandler(const CYBLE_CONN_HANDLE_T *eventParam)
{
    uint8 locReqHandle = 0u;
    CYBLE_OTS_CHAR_INDEX_T locCharIndex;
    
    if((NULL != CyBle_OtsApplCallback) && (CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE != cyBle_otscReqHandle))
    {
        for(locCharIndex = CYBLE_OTS_FEATURE; (locCharIndex < CYBLE_OTS_CHAR_COUNT) && (locReqHandle == 0u); 
            locCharIndex++)
        {
            if(cyBle_otscReqHandle == cyBle_otsc.charInfo[locCharIndex].valueHandle)
            {
                CYBLE_OTS_CHAR_VALUE_T locCharValue;
                
                locCharValue.connHandle = *eventParam;
                locCharValue.charIndex = locCharIndex;
                locCharValue.value = NULL;
                cyBle_otscReqHandle = CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE;
                CyBle_OtsApplCallback((uint32)CYBLE_EVT_OTSC_WRITE_CHAR_RESPONSE, &locCharValue);
                locReqHandle = 1u;
            }
            else 
            {
            
                CYBLE_OTS_DESCR_INDEX_T locDescIndex;

                for(locDescIndex = CYBLE_OTS_CCCD; (locDescIndex < CYBLE_OTS_DESCR_COUNT) &&
                   (locReqHandle == 0u); locDescIndex++)
                {
                    if(cyBle_otscReqHandle == cyBle_otsc.charInfo[locCharIndex].descrHandle[locDescIndex])
                    {
                        CYBLE_OTS_DESCR_VALUE_T locDescrValue;
                        
                        locDescrValue.connHandle = *eventParam;
                        locDescrValue.charIndex = locCharIndex;
                        locDescrValue.descrIndex = locDescIndex;
                        locDescrValue.value = NULL;
                        cyBle_otscReqHandle = CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE;
                        CyBle_OtsApplCallback((uint32)CYBLE_EVT_OTSC_WRITE_DESCR_RESPONSE, &locDescrValue);
                        locReqHandle = 1u;
                    }
                }
            }
        }
        if(locReqHandle != 0u)
        {
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
    }
}

/******************************************************************************
* Function Name: CyBle_OtscExecuteWriteResponseEventHandler
***************************************************************************//**
* 
*  Handles a Execute Write Response event for the Object Transfer Service.
* 
*  \param eventParam: The pointer to a data structure specified by an event.
* 
******************************************************************************/
void CyBle_OtscExecuteWriteResponseEventHandler(const CYBLE_GATTC_EXEC_WRITE_RSP_T *eventParam)
{
    uint8 i;
    CYBLE_OTS_CHAR_VALUE_T locCharVal;

    if((NULL != CyBle_OtsApplCallback) && (CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE != cyBle_otscReqHandle))
    {
        for(i = 0u; i < ((uint8) CYBLE_OTS_CHAR_COUNT); i++)
        {
            if(cyBle_otsc.charInfo[i].valueHandle == cyBle_otscReqHandle)
            {
                locCharVal.connHandle = eventParam->connHandle;
                locCharVal.charIndex = (CYBLE_OTS_CHAR_INDEX_T) i;
                locCharVal.value = NULL;
                cyBle_otscReqHandle = CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE;
                CyBle_OtsApplCallback((uint32) CYBLE_EVT_OTSC_WRITE_CHAR_RESPONSE, &locCharVal);
                cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
            }
        }
    }
}


/******************************************************************************
* Function Name: CyBle_OtscIndicationEventHandler
***************************************************************************//**
* 
*  Handles an indication event for Object Transfer Service.
* 
*  \param eventParam: The pointer to the data structure specified by an event.
*  
******************************************************************************/
void CyBle_OtscIndicationEventHandler(CYBLE_GATTC_HANDLE_VALUE_IND_PARAM_T *eventParam)
{
    CYBLE_OTS_CHAR_INDEX_T locCharIndex;
    CYBLE_OTS_CHAR_VALUE_T indicationValue;

    if(CyBle_OtsApplCallback != NULL)
    {
        for(locCharIndex = CYBLE_OTS_FEATURE; locCharIndex < CYBLE_OTS_CHAR_COUNT; locCharIndex++)
        {
            if(cyBle_otsc.charInfo[locCharIndex].valueHandle ==
                eventParam->handleValPair.attrHandle)
            {
                indicationValue.connHandle = eventParam->connHandle;
                indicationValue.charIndex = locCharIndex;
                indicationValue.value = &eventParam->handleValPair.value;
                CyBle_OtsApplCallback((uint32) CYBLE_EVT_OTSC_INDICATION, &indicationValue);
                cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
                break;
            }
        }
    }
}


/******************************************************************************
* Function Name: CyBle_OtscErrorResponseEventHandler
***************************************************************************//**
* 
*  Handles the Error Response Event.
* 
*  \param eventParam: The pointer to the data structure specified by the event.
* 
******************************************************************************/
void CyBle_OtscErrorResponseEventHandler(const CYBLE_GATTC_ERR_RSP_PARAM_T *eventParam)
{
    if((eventParam != NULL) && (eventParam->attrHandle == cyBle_otscReqHandle))
    {
        if((eventParam->opCode == CYBLE_GATT_READ_BLOB_REQ) &&
           (eventParam->errorCode == CYBLE_GATT_ERR_ATTRIBUTE_NOT_LONG))
        {
            (void)CyBle_GattcReadCharacteristicValue(eventParam->connHandle, eventParam->attrHandle);
            cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
        }
        else
        {   
            if(CyBle_OtsApplCallback != NULL)
            {
                CYBLE_OTS_CHAR_VALUE_T locGattError;
                locGattError.connHandle = eventParam->connHandle;
                locGattError.value = NULL;
                locGattError.gattErrorCode = eventParam->errorCode;
            
                for(locGattError.charIndex = CYBLE_OTS_FEATURE; 
                    locGattError.charIndex < CYBLE_OTS_CHAR_COUNT; 
                    locGattError.charIndex++)
                {
                    if(cyBle_otsc.charInfo[locGattError.charIndex].valueHandle == eventParam->attrHandle)
                    {
                        CyBle_OtsApplCallback((uint32)CYBLE_EVT_OTSC_ERROR_RESPONSE, &locGattError);
                        cyBle_eventHandlerFlag &= (uint8)~CYBLE_CALLBACK;
                        break;
                    }
                }
            }
            
            cyBle_otscReqHandle = CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE;
        }
    }
}

#endif /* CYBLE_OTS_CLIENT */


/* [] END OF FILE */

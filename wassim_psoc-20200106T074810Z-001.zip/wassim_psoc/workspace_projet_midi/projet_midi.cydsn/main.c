/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "common.h"

volatile int foo = 0;
static volatile uint8 valeurmidi = 0;
static volatile uint8 on_off=0;

typedef struct {
    uint16_t current_mA;
    uint16_t voltage_V;
    int16_t temperature;
    uint16_t puissance;
    int16_t frequence;
    // TODO: etc.
} my_values_t;

volatile my_values_t my_values = {
    0,  // current_mA
    0,  // voltage_V
    0,  // temperature
    0,  // puissance
    0,  // frequence
};

void EvtCallBack(unsigned long eventCode, void* eventParam)
{
    foo++;
    // TODO
    if(eventParam != 0u)
    {
        /*pour eviter warning a cause de event param*/
    }
    switch(eventCode)
    {
        /* Mandatory events to be handled by Find Me Target design */
        case CYBLE_EVT_STACK_ON:
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            /* Start BLE advertisement for 30 seconds and update link
             * status on LEDs */
            CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
            Advertising_LED_Write(LED_ON);
        break;
            
        case CYBLE_EVT_GAP_DEVICE_CONNECTED:
            /* BLE link is established */
            Advertising_LED_Write(LED_OFF);
        break;
            
        case CYBLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
            if(CyBle_GetState() == CYBLE_STATE_DISCONNECTED)
            {
                Advertising_LED_Write(LED_OFF);
                Hibernate_LED_Write(LED_ON);
            }
        break;
            
        case CYBLE_EVT_GATTS_READ_CHAR_VAL_ACCESS_REQ: {
            CYBLE_GATTS_CHAR_VAL_READ_REQ_T *d = eventParam;
            switch (d->attrHandle) {
            case CYBLE_ENVOI_DINFOS_SERVICE_COURANT_CHAR_HANDLE: {
                CYBLE_GATT_HANDLE_VALUE_PAIR_T value;
                value.attrHandle = d->attrHandle;
                value.value.actualLen = sizeof(my_values.current_mA);
                value.value.len = sizeof(my_values.current_mA);
                uint8_t data[2];
                data[0] = my_values.current_mA >> 8;
                data[1] = my_values.current_mA & 0xFF;
                value.value.val = data;
                CyBle_GattsReadAttributeValue(&value, &d->connHandle,CYBLE_GATT_DB_PEER_INITIATED);
                break;
            }
            case CYBLE_ENVOI_DINFOS_SERVICE_TENSION_CHAR_HANDLE: {
                CYBLE_GATT_HANDLE_VALUE_PAIR_T value;
                value.attrHandle = d->attrHandle;
                value.value.actualLen = sizeof(my_values.voltage_V);
                value.value.len = sizeof(my_values.voltage_V);
                uint8_t data[2];
                data[0] = my_values.voltage_V >> 8;
                data[1] = my_values.voltage_V & 0xFF;
                value.value.val = data;
                CyBle_GattsReadAttributeValue(&value, &d->connHandle,CYBLE_GATT_DB_PEER_INITIATED);
                break;
            }
            case CYBLE_ENVOI_DINFOS_SERVICE_TEMPERATURE_CHAR_HANDLE: {
                CYBLE_GATT_HANDLE_VALUE_PAIR_T value;
                value.attrHandle = d->attrHandle;
                value.value.actualLen = sizeof(my_values.temperature);
                value.value.len = sizeof(my_values.temperature);
                uint8_t data[2];
                data[0] = my_values.temperature >> 8;
                data[1] = my_values.temperature & 0xFF;
                value.value.val = data;
                CyBle_GattsReadAttributeValue(&value, &d->connHandle,CYBLE_GATT_DB_PEER_INITIATED);
                break;
            }
            case CYBLE_ENVOI_DINFOS_SERVICE_PUISSANCE_CHAR_HANDLE: {
                CYBLE_GATT_HANDLE_VALUE_PAIR_T value;
                value.attrHandle = d->attrHandle;
                value.value.actualLen = sizeof(my_values.puissance);
                value.value.len = sizeof(my_values.puissance);
                uint8_t data[2];
                data[0] = my_values.puissance >> 8;
                data[1] = my_values.puissance & 0xFF;
                value.value.val = data;
                CyBle_GattsReadAttributeValue(&value, &d->connHandle,CYBLE_GATT_DB_PEER_INITIATED);
                break;
            }
            case CYBLE_ENVOI_DINFOS_SERVICE_FREQUENCE_CHAR_HANDLE: {
                CYBLE_GATT_HANDLE_VALUE_PAIR_T value;
                value.attrHandle = d->attrHandle;
                value.value.actualLen = sizeof(my_values.frequence);
                value.value.len = sizeof(my_values.frequence);
                uint8_t data[2];
                data[0] = my_values.frequence >> 8;
                data[1] = my_values.frequence & 0xFF;
                value.value.val = data;
                CyBle_GattsReadAttributeValue(&value, &d->connHandle,CYBLE_GATT_DB_PEER_INITIATED);
                break;
            }
                break;
                
            }
        }
        break;
            
        case CYBLE_EVT_GATTS_WRITE_CMD_REQ: {
            CYBLE_GATTS_WRITE_CMD_REQ_PARAM_T *d = eventParam;
            switch (d->handleValPair.attrHandle) {
                case CYBLE_ENVOI_DINFOS_SERVICE_START_AND_STOP_CHAR_HANDLE:{
                    on_off = *d->handleValPair.value.val;
                break;
                }
                case CYBLE_MIDI_SERVICE_SERVICE_MIDI_CHAR_HANDLE:{
                    valeurmidi = *d->handleValPair.value.val;
                break;
                }
                
            default:
                // Not handled
                break;
            }
            CyBle_GattsWriteRsp(d->connHandle);
        }
        break;
            
    }   
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_1_Start();
    CyBle_Start(EvtCallBack);
    for(;;)
    {
        my_values.current_mA=241;
        CyBle_ProcessEvents();
        (void) foo;
    }
    
}

/* [] END OF FILE */

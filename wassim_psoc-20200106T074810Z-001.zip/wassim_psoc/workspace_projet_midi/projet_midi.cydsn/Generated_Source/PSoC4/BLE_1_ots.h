/***************************************************************************//**
* \file BLE_ots.h
* \version 3.61
* 
* \brief
*  Contains the function prototypes and constants for the Object Transfer
*  Service.
* 
********************************************************************************
* \copyright
* Copyright 2019, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

/**
 \addtogroup group_service_api_OTS_definitions
 @{
*/


#if !defined(CY_BLE_CYBLE_OTS_H)
#define CY_BLE_CYBLE_OTS_H

#include "BLE_1_gatt.h"

/***************************************
* Data Struct Definition
***************************************/

/** OTS Characteristic indexes */
typedef enum
{
    CYBLE_OTS_FEATURE,                          /**< Exposes which optional features are supported by the Server implementation.*/
    CYBLE_OTS_OBJECT_NAME,                      /**< The name of the Current Object. */
    CYBLE_OTS_OBJECT_TYPE,                      /**< The type of the Current Object, identifying the object type by UUID. */
    CYBLE_OTS_OBJECT_SIZE,                      /**< The current size as well as the allocated size of the Current Object. */
    CYBLE_OTS_OBJECT_FIRST_CREATED,             /**< Date and time when the object contents were first created. */
    CYBLE_OTS_OBJECT_LAST_MODIFIED,             /**< Date and time when the object content was last modified. */
    CYBLE_OTS_OBJECT_ID,                        /**< The Object ID of the Current Object. The Object ID is a LUID (Locally Unique Identifier). */
    CYBLE_OTS_OBJECT_PROPERTIES,                /**< The properties of the Current Object. */
    CYBLE_OTS_OBJECT_ACTION_CONTROL_POINT,      /**< Is used by a Client to control certain behaviors of the Server. */
    CYBLE_OTS_OBJECT_LIST_CONTROL_POINT,        /**< Provides a mechanism for the Client to find the desired object and to designate it as the Current Object. */
    CYBLE_OTS_OBJECT_LIST_FILTER_1,             /**< The filter conditions determines which objects are included in or excluded from the list of objects.*/
    CYBLE_OTS_OBJECT_LIST_FILTER_2,             /**< The filter conditions determines which objects are included in or excluded from the list of objects.*/
    CYBLE_OTS_OBJECT_LIST_FILTER_3,             /**< The filter conditions determines which objects are included in or excluded from the list of objects.*/
    CYBLE_OTS_OBJECT_CHANGED,                   /**< Enables a Client to receive an indication if the contents and/or metadata of one or more objects are changed.*/
    CYBLE_OTS_CHAR_COUNT                        /**< Total count of OTS characteristics */
}CYBLE_OTS_CHAR_INDEX_T;

/** OTS Characteristic Descriptors indexes */
typedef enum
{   
    CYBLE_OTS_CCCD,                              /**< Client Characteristic Configuration Descriptor index */
    CYBLE_OTS_DESCR_COUNT                        /**< Total count of descriptors */
}CYBLE_OTS_DESCR_INDEX_T;

#ifdef CYBLE_OTS_SERVER

/** OTS Characteristic with descriptors */
typedef struct
{
    /** Handles of Characteristic value */
    CYBLE_GATT_DB_ATTR_HANDLE_T charHandle;

    /** Array of Descriptor handles */
    CYBLE_GATT_DB_ATTR_HANDLE_T descrHandle[CYBLE_OTS_DESCR_COUNT];
} CYBLE_OTSS_CHAR_T;

/** Structure to hold pointer to CYBLE_OTSS_CHAR_T */
typedef struct
{
    /** Pointer to CYBLE_OTSS_CHAR_T which holds information about specific
    * IP Characteristic
    */
    CYBLE_OTSS_CHAR_T *charInfoPtr;
} CYBLE_OTSS_CHAR_INFO_PTR_T;

/** Structure with Object Transfer Service attribute handles */
typedef struct
{
    /** Object Transfer Service handle */
    CYBLE_GATT_DB_ATTR_HANDLE_T serviceHandle;

    /** Object Transfer Service Array with pointers to
    * Characteristic handles.
    */
    CYBLE_OTSS_CHAR_T charInfo[CYBLE_OTS_CHAR_COUNT];
} CYBLE_OTSS_T;

#endif /* CYBLE_OTS_SERVER */

#ifdef CYBLE_OTS_CLIENT

/** OTS Characteristic with descriptors */
typedef struct
{
    CYBLE_GATT_DB_ATTR_HANDLE_T valueHandle;                        /**< Handle of characteristic value */
    CYBLE_GATT_DB_ATTR_HANDLE_T endHandle;                          /**< End handle of characteristic */
    CYBLE_GATT_DB_ATTR_HANDLE_T descrHandle[CYBLE_OTS_DESCR_COUNT]; /**< Array of Descriptor handles */
    uint8  properties;                                              /**< Properties for value field */
} CYBLE_OTSC_CHAR_T;

/** Structure to hold pointer to CYBLE_OTSC_CHAR_T */
typedef struct
{
    /** Pointer to CYBLE_OTSC_CHAR_T which holds information about specific OTS Characteristic. */
    CYBLE_OTSC_CHAR_T *charInfoPtr;
} CYBLE_OTSC_CHAR_INFO_PTR_T;

/** Structure with discovered attributes information of Object Transfer Service. */
typedef struct
{
    /** Object Transfer Service handle */
    CYBLE_GATT_DB_ATTR_HANDLE_T serviceHandle;
       
    /** Object Transfer Service characteristics info array */
    CYBLE_OTSC_CHAR_T charInfo[CYBLE_OTS_CHAR_COUNT];
} CYBLE_OTSC_T;

#endif /* CYBLE_OTS_CLIENT */

/** OTS Characteristic value parameter structure */
typedef struct
{
    CYBLE_CONN_HANDLE_T connHandle;                         /**< Peer device handle */
    CYBLE_OTS_CHAR_INDEX_T charIndex;                       /**< Index of service characteristic */
    CYBLE_GATT_VALUE_T *value;                              /**< Characteristic value */
    CYBLE_GATT_ERR_CODE_T gattErrorCode;                    /**< GATT error code for access control */
} CYBLE_OTS_CHAR_VALUE_T;

/** OTS Characteristic descriptor value parameter structure */
typedef struct
{
    CYBLE_CONN_HANDLE_T connHandle;                         /**< Peer device handle */
    CYBLE_OTS_CHAR_INDEX_T charIndex;                       /**< Index of service characteristic */
    CYBLE_OTS_DESCR_INDEX_T descrIndex;                     /**< Index of descriptor */
    CYBLE_GATT_ERR_CODE_T gattErrorCode;                    /**< Error code received from application (optional) */
    CYBLE_GATT_VALUE_T *value;                              /**< Characteristic value */
} CYBLE_OTS_DESCR_VALUE_T;

/** @} */

/***************************************
* API Constants
***************************************/
/* OTS specific GATT errors  */
#define CYBLE_GATT_ERR_WRITE_REQ_REJECTED          (0x80u)  /*  An attempt was made to write a value that is invalid or 
                                                             *  not supported by this Server for a reason other than the 
                                                             *  attribute permissions. 
                                                             */
#define CYBLE_GATT_ERR_OBJECT_NOT_SELECTED 	       (0x81u) 	/*  An attempt was made to read or write to an Object Metadata
                                                             *  characteristic while the Current Object was an Invalid Object
                                                             */
#define CYBLE_GATT_ERR_CONCURRENCY_LIMIT_EXCEEDED  (0x82u)	/*  The Server is unable to service the Read Request or Write 
                                                             *  Request because it exceeds the concurrency limit of the 
                                                             *  service. 
                                                             */
#define CYBLE_GATT_ERR_OBJECT_NAME_ALREADY_EXISTS  (0x83u) 	/*  The requested object name was rejected because the name was 
                                                             *  already in use by an existing object on the Server. 
                                                             */ 

#define CYBLE_OTS_MIN_SIZE_PTR                     (1u)
#define CYBLE_OTS_MAX_SIZE_PTR                     (5u)


/** OACP Features Field */
/** When a bit is set to 1 (True) in the OACP Features field, the Server supports the associated operation as defined in the following table: */
typedef enum
{
    CYBLE_OTS_OACP_MASK_CREATE     = 0x0001, /**< OACP Create Op Code Supported. */ 
    CYBLE_OTS_OACP_MASK_DELETE     = 0x0002, /**< OACP Delete Op Code Supported. */ 
    CYBLE_OTS_OACP_MASK_CHECKSUM   = 0x0004, /**< OACP Calculate Checksum Op Code Supported. */ 
    CYBLE_OTS_OACP_MASK_EXECUTE    = 0x0008, /**< OACP Execute Op Code Supported. */ 
    CYBLE_OTS_OACP_MASK_READ       = 0x0010, /**< OACP Read Op Code Supported. */ 
    CYBLE_OTS_OACP_MASK_WRITE      = 0x0020, /**< OACP Write Op Code Supported. */ 
    CYBLE_OTS_OACP_MASK_APPENDING  = 0x0040, /**< Appending Additional Data to Objects Supported. */ 
    CYBLE_OTS_OACP_MASK_TRUNCATION = 0x0080, /**< Truncation of Objects Supported. */ 
    CYBLE_OTS_OACP_MASK_PATCHING   = 0x0100, /**< Patching of Objects Supported. */ 
    CYBLE_OTS_OACP_MASK_ABORT      = 0x0200  /**<  OACP Abort Op Code Supported. */ 
}CYBLE_OTS_OACP_FEATURE_MASK_T;



/** OLCP Features Field */ 
/** When a bit is set to 1 (True) in the OLCP Features field, the Server supports the associated operation as defined in the following table: */
typedef enum
{
    CYBLE_OTS_OLCP_MASK_GO_TO          = 0x0001, /**<  OLCP Go To Op Code Supported. */
    CYBLE_OTS_OLCP_MASK_ORDER          = 0x0002, /**<  OLCP Order Op Code Supported. */
    CYBLE_OTS_OLCP_MASK_REQUEST_NUMBER = 0x0004, /**<  OLCP Request Number of Objects Op Code Supported. */
    CYBLE_OTS_OLCP_MASK_CLEAR_MARKING  = 0x0008  /**<  OLCP Clear Marking Op Code Supported. */
}CYBLE_OTS_OLCP_FEATURE_MASK_T;


/** Object Properties Characteristic */ 
/** When a bit of the Object Properties characteristic is set to 1 (i.e. True), the Current Object possesses the associated property.*/
typedef enum
{
    CYBLE_OTS_PROPERTY_DELETE   = 0x01, /**< Deletion of this object is permitted. */
    CYBLE_OTS_PROPERTY_EXECUTE  = 0x02, /**< Execution of this object is permitted. */
    CYBLE_OTS_PROPERTY_READ     = 0x04, /**< Reading this object is permitted. */
    CYBLE_OTS_PROPERTY_WRITE    = 0x08, /**< Writing data to this object is permitted. */
    CYBLE_OTS_PROPERTY_APPEND   = 0x10, /**< Appending data to this object that increases its Allocated Size is permitted. */
    CYBLE_OTS_PROPERTY_TRUNCATE = 0x20, /**< Truncation of this object is permitted. */
    CYBLE_OTS_PROPERTY_PATCH    = 0x40, /**< Patching this object by overwriting some of the object’s existing contents is permitted. */
    CYBLE_OTS_PROPERTY_MARK     = 0x80  /**< This object is a marked object. */
}CYBLE_OTS_OACP_PROPERTY_MASK_T;

/** Object Action Control Point Procedure Requirements */
typedef enum
{
    CYBLE_OTS_OACP_CREATE = 0x01,
    CYBLE_OTS_OACP_DELETE,
    CYBLE_OTS_OACP_CALCULATE_CHECKSUM,
    CYBLE_OTS_OACP_EXECUTE, 
    CYBLE_OTS_OACP_READ,
    CYBLE_OTS_OACP_WRITE,
    CYBLE_OTS_OACP_ABORT,
    CYBLE_OTS_OACP_RESPONSE_CODE = 0x60
}CYBLE_OTS_OACP_PROCEDURE_T;

/** The Result Codes associated with Op Code 0x60 */
typedef enum
{
    CYBLE_OTS_OACP_SUCCESS = 0x01,          /**< Response for successful operation.*/
    CYBLE_OTS_OACP_OP_CODE_NOT_SUPPORTED,   /**< Response if unsupported Op Code is received.*/
    CYBLE_OTS_OACP_INVALID_PARAMETER,       /**< Response if Parameter received does not meet the requirements of the service.*/
    CYBLE_OTS_OACP_INSUFFICIENT_RESOURCES,  /**< Response if the number of octets requested via the value of the Length parameter or Size parameter (as applicable) exceeds the available memory or processing capabilities of the Server.*/
    CYBLE_OTS_OACP_INVALID_OBJECT,          /**< Response if the requested OACP procedure cannot be performed because the Current Object is an Invalid Object.*/
    CYBLE_OTS_OACP_CHANNEL_UNAVAILABLE,     /**< Response if the requested procedure could not be performed because an Object Transfer Channel was not available for use.*/
    CYBLE_OTS_OACP_UNSUPPORTED_TYPE,        /**< Response if the object type specified in the OACP procedure Type parameter is not supported by the Server.*/
    CYBLE_OTS_OACP_PROCEDURE_NOT_PERMITTED, /**< Response if the requested procedure is not permitted according to the properties of the Current Object.*/
    CYBLE_OTS_OACP_OBJECT_LOCKED,           /**< Response if the Current Object is temporarily locked by the Server.*/
    CYBLE_OTS_OACP_OPERATION_FAILED         /**< Response if the requested procedure failed for any reason other than those enumerated.*/
}CYBLE_OTS_OACP_RESPONSE_T;

/** Object List Control Point Procedure Requirements*/
typedef enum
{
    CYBLE_OTS_OLCP_FIRST = 0x01,
    CYBLE_OTS_OLCP_LAST, 
    CYBLE_OTS_OLCP_PREVIOUS,
    CYBLE_OTS_OLCP_NEXT,
    CYBLE_OTS_OLCP_GO_TO,
    CYBLE_OTS_OLCP_ORDER,
    CYBLE_OTS_OLCP_REQUEST_NUMBER_OF_OBJECTS,
    CYBLE_OTS_OLCP_CLEAR_MARKING,
    CYBLE_OTS_OLCP_RESPONSE_CODE = 0x70
}CYBLE_OTS_OLCP_PROCEDURE_T;

/** The List Sort Order Parameter*/
typedef enum
{
    CYBLE_OTS_LSO_NAME_ASC = 0x01,          /**< Order the list by object name, ascending.*/
    CYBLE_OTS_LSO_TYPE_ASC = 0x02,          /**< Order the list by object type, ascending.*/
    CYBLE_OTS_LSO_SIZE_ASC = 0x03,          /**< Order the list by object current size, ascending.*/
    CYBLE_OTS_LSO_FIRST_CREATED_ASC = 0x04, /**< Order the list by object first-created timestamp, ascending.*/
    CYBLE_OTS_LSO_LAST_MODIFIED_ASC = 0x05, /**< Order the list by object last-modified timestamp, ascending.*/
    CYBLE_OTS_LSO_NAME_DES = 0x11,          /**< Order the list by object name, descending.*/
    CYBLE_OTS_LSO_TYPE_DES = 0x12,          /**< Order the list by object type, descending.*/
    CYBLE_OTS_LSO_SIZE_DES = 0x13,          /**< Order the list by object current size, descending.*/
    CYBLE_OTS_LSO_FIRST_CREATED_DES = 0x14, /**< Order the list by object first-created timestamp, descending.*/
    CYBLE_OTS_LSO_LAST_MODIFIED_DES = 0x15  /**< Order the list by object last-modified timestamp, descending.*/
}CYBLE_OTS_LSO_ORDER_T;

/** The Result Codes and Response Parameters associated with Op Code 0x70*/
typedef enum
{
    CYBLE_OTS_OLCP_SUCCESS = 0x01, 	        /**< Response for successful operation.*/
    CYBLE_OTS_OLCP_OP_CODE_NOT_SUPPORTED,   /**< Response if unsupported Op Code is received.*/
    CYBLE_OTS_OLCP_INVALID_PARAMETER,       /**< Response if Parameter received does not meet the requirements of the service.*/
    CYBLE_OTS_OLCP_OPERATION_FAILED,        /**< Response if the requested procedure failed for a reason other than those enumerated below.*/
    CYBLE_OTS_OLCP_OUT_OF_BOUNDS,           /**< Response if the requested procedure attempted to select an object beyond the first object or beyond the last object in the current list.*/
    CYBLE_OTS_OLCP_TOO_MANY_OBJECTS,        /**< Response if the requested procedure failed due to too many objects in the current list.*/
    CYBLE_OTS_OLCP_NO_OBJECT,               /**< Response if the requested procedure failed due to there being zero objects in the current list.*/
    CYBLE_OTS_OLCP_OBJECT_ID_NOT_FOUND,     /**< Response if the requested procedure failed due to there being no object with the requested Object ID.*/
}CYBLE_OTS_OLCP_RESPONSE_T;


/** The format of the Parameter depends on the Filter value.*/
typedef enum
{
    CYBLE_OTS_OLF_NO_FILTER = 0x00,
    CYBLE_OTS_OLF_NAME_STARTS_WITH,
    CYBLE_OTS_OLF_NAME_ENDS_WITH,
    CYBLE_OTS_OLF_NAME_CONTAINS,
    CYBLE_OTS_OLF_NAME_IS_EXACTLY,
    CYBLE_OTS_OLF_OBJECT_TYPE,
    CYBLE_OTS_OLF_CREATED_BETWEEN,
    CYBLE_OTS_OLF_MODIFIED_BETWEEN,
    CYBLE_OTS_OLF_CURRENT_SIZE_BETWEEN,
    CYBLE_OTS_OLF_ALLOCATED_SIZE_BETWEEN,
    CYBLE_OTS_OLF_MARKED_OBJECTS
}CYBLE_OTS_OLF_FILTER_T;

typedef enum
{
    CYBLE_OC_SOURCE_OF_CHANGE_CLIENT = 0x01,
    CYBLE_OC_CHANGED_CONTENT = 0x02,
    CYBLE_OC_CHANGED_METADATA = 0x04,
    CYBLE_OC_OBJECT_CREATION = 0x08,
    CYBLE_OC_OBJECT_DELETION = 0x10
}CYBLE_OC_FLAGS_T;    


#if(CYBLE_GAP_ROLE_PERIPHERAL)
  
    
#endif /* (CYBLE_GAP_ROLE_PERIPHERAL) */

/***************************************
* Function Prototypes
***************************************/

/** \addtogroup group_service_api_OTS_server_client 
@{ 
*/
void CyBle_OtsRegisterAttrCallback(CYBLE_CALLBACK_T callbackFunc);
/** @} */

#ifdef CYBLE_OTS_SERVER
/**
 \addtogroup group_service_api_OTS_server
 @{
*/

CYBLE_API_RESULT_T CyBle_OtssSetCharacteristicValue(CYBLE_OTS_CHAR_INDEX_T charIndex, uint8 attrSize, uint8 *attrValue);
CYBLE_API_RESULT_T CyBle_OtssGetCharacteristicValue(CYBLE_OTS_CHAR_INDEX_T charIndex, uint8 attrSize, uint8 *attrValue);
CYBLE_API_RESULT_T CyBle_OtssSetCharacteristicDescriptor(CYBLE_OTS_CHAR_INDEX_T charIndex, CYBLE_OTS_DESCR_INDEX_T descrIndex, uint8 attrSize, uint8 *attrValue);
CYBLE_API_RESULT_T CyBle_OtssGetCharacteristicDescriptor(CYBLE_OTS_CHAR_INDEX_T charIndex, CYBLE_OTS_DESCR_INDEX_T descrIndex, uint8 attrSize, uint8 *attrValue);
CYBLE_API_RESULT_T CyBle_OtssSendIndication(CYBLE_CONN_HANDLE_T connHandle, CYBLE_OTS_CHAR_INDEX_T charIndex, uint8 attrSize, uint8 *attrValue);

#endif /* CYBLE_OTS_SERVER */

/** @} */

#ifdef CYBLE_OTS_CLIENT
/**
 \addtogroup group_service_api_OTS_client
 @{
*/
CYBLE_API_RESULT_T CyBle_OtscSetCharacteristicValue(CYBLE_CONN_HANDLE_T connHandle,
                                                        CYBLE_OTS_CHAR_INDEX_T charIndex,
                                                        uint8 attrSize, uint8 *attrValue);

CYBLE_API_RESULT_T CyBle_OtscSetLongCharacteristicValue(CYBLE_CONN_HANDLE_T connHandle, 
                                                        CYBLE_OTS_CHAR_INDEX_T charIndex,
                                                        uint16 attrSize, uint8 *attrValue);

CYBLE_API_RESULT_T CyBle_OtscGetCharacteristicValue(CYBLE_CONN_HANDLE_T connHandle, 
                                                        CYBLE_OTS_CHAR_INDEX_T charIndex);

CYBLE_API_RESULT_T CyBle_OtscGetLongCharacteristicValue(CYBLE_CONN_HANDLE_T connHandle, 
                                                        CYBLE_OTS_CHAR_INDEX_T charIndex, 
                                                        uint16 attrSize,
                                                        uint8 *attrValue);

CYBLE_API_RESULT_T CyBle_OtscSetCharacteristicDescriptor(CYBLE_CONN_HANDLE_T connHandle,
                                                        CYBLE_OTS_CHAR_INDEX_T charIndex,
                                                        CYBLE_OTS_DESCR_INDEX_T descrIndex,
                                                        uint8 attrSize, uint8 *attrValue);

CYBLE_API_RESULT_T CyBle_OtscGetCharacteristicDescriptor(CYBLE_CONN_HANDLE_T connHandle,
                                                        CYBLE_OTS_CHAR_INDEX_T charIndex,
                                                        CYBLE_OTS_DESCR_INDEX_T descrIndex);

/** @} */
#endif /* CYBLE_OTS_CLIENT */


/***************************************
* Private Function Prototypes
***************************************/

/** \cond IGNORE */
void CyBle_OtsInit(void);

#ifdef CYBLE_OTS_SERVER

CYBLE_GATT_ERR_CODE_T CyBle_OtssWriteEventHandler(CYBLE_GATTS_WRITE_REQ_PARAM_T *eventParam);
void CyBle_OtssPrepareWriteRequestEventHandler(CYBLE_GATTS_PREP_WRITE_REQ_PARAM_T *eventParam);
void CyBle_OtssExecuteWriteRequestEventHandler(CYBLE_GATTS_EXEC_WRITE_REQ_T *eventParam);
void CyBle_OtssConfirmationEventHandler(const CYBLE_CONN_HANDLE_T *eventParam);
uint32 CyBle_OtsGet32ByPtr(const uint8 ptr[]);
#endif /* CYBLE_OTS_SERVER */

#ifdef CYBLE_OTS_CLIENT
    
void CyBle_OtscDiscoverCharacteristicsEventHandler(CYBLE_DISC_CHAR_INFO_T * discCharInfo);
void CyBle_OtscDiscoverCharDescriptorsEventHandler(CYBLE_OTS_CHAR_INDEX_T discoveryCharIndex, CYBLE_DISC_DESCR_INFO_T * discDescrInfo);
void CyBle_OtscReadResponseEventHandler(CYBLE_GATTC_READ_RSP_PARAM_T *eventParam);
void CyBle_OtscReadLongRespEventHandler(const CYBLE_GATTC_READ_RSP_PARAM_T *eventParam);
void CyBle_OtscWriteResponseEventHandler(const CYBLE_CONN_HANDLE_T *eventParam);
void CyBle_OtscErrorResponseEventHandler(const CYBLE_GATTC_ERR_RSP_PARAM_T *eventParam);
void CyBle_OtscExecuteWriteResponseEventHandler(const CYBLE_GATTC_EXEC_WRITE_RSP_T *eventParam);
void CyBle_OtscIndicationEventHandler(CYBLE_GATTC_HANDLE_VALUE_IND_PARAM_T *eventParam);

#endif /* CYBLE_OTS_CLIENT */
/** \endcond */


/***************************************
* Macro Functions
***************************************/

#define CyBle_OtsGet16ByPtr    CyBle_Get16ByPtr

#ifdef CYBLE_OTS_CLIENT

#define CyBle_OtscGetCharacteristicValueHandle(charIndex)    \
    (((charIndex) >= CYBLE_OTS_CHAR_COUNT) ? \
            CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE : \
            cyBle_otsc.charInfo[charIndex].valueHandle)

#define CyBle_OtscGetCharacteristicDescriptorHandle(charIndex, descrIndex)    \
    ((((charIndex) >= CYBLE_OTS_CHAR_COUNT) || ((descrIndex) >= CYBLE_OTS_DESCR_COUNT)) ? \
            CYBLE_GATT_INVALID_ATTR_HANDLE_VALUE : \
            cyBle_otsc.charInfo[charIndex].descrHandle[descrIndex])

#endif /* (CYBLE_OTS_CLIENT) */


/***************************************
* External data references
***************************************/

#ifdef CYBLE_OTS_SERVER

extern const CYBLE_OTSS_T cyBle_otss;
extern uint8 cyBle_otsFlag;

#endif /* CYBLE_OTS_SERVER */

#ifdef CYBLE_OTS_CLIENT

extern CYBLE_OTSC_T cyBle_otsc;

#endif /* (CYBLE_OTS_CLIENT) */

#endif /* CY_BLE_CYBLE_OTS_H */


/* [] END OF FILE */
